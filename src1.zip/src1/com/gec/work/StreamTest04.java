package com.gec.work;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamTest04 {
	public static void main(String[] args) {
		//组装数据
		List<Emp> list = new ArrayList<>();
		list.add(new Emp("张三", 9500, 23, "男", "深圳"));
		list.add(new Emp("李四", 6900, 22, "男", "佛山"));
		list.add(new Emp("王五", 7800, 22, "男", "深圳"));
		list.add(new Emp("李全", 8300, 23, "男", "广州"));
		list.add(new Emp("黄二狗", 7500, 23, "男", "东莞"));
		
		//统计员工人数、平均工资、工资总额、最高工资。Stream完成
		System.out.println("员工人数:" + list.stream().collect(Collectors.counting()));
		System.out.println("平均工资:" + list.stream().collect(Collectors.averagingDouble(Emp::getSalary)));
		System.out.println("工资总额:" + list.stream().collect(Collectors.summarizingDouble(Emp::getSalary)).getSum());
		System.out.println("最高工资:" + list.stream().map(Emp::getSalary).collect(Collectors.maxBy(Integer::compare)).get());
		
	}
}
