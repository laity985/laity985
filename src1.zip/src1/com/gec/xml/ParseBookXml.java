package com.gec.xml;

import java.io.FileInputStream;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ParseBookXml {
	 @Test
    public void get() throws Exception {
        // 获取工厂实例对象
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        // 获取解析器对象
        DocumentBuilder db = dbf.newDocumentBuilder();
        // 解析xml获取dom对象
        Document dom = db.parse("src/books.xml");
        // 获取根元素：
        Node node = dom.getFirstChild();
        // 获取标签的名字
        System.out.println(node.getNodeName());//books
        // 获取到每个标签对象，都是一个element的实例对象
        Element root = (Element) node;
        // 获取books下面的所有book标签
        NodeList nl = root.getElementsByTagName("book");
        for (int i = 0; i < nl.getLength(); i++) {
            // 获取到每个book标签对象
            Element book = (Element) nl.item(i);
            // NodeList book_child = book.getChildNodes();
            //根据名字找到标签  <title>西游记</title>
            Element title = (Element) book.getElementsByTagName("title").item(0);
            Element author = (Element) book.getElementsByTagName("author").item(0);
            Element price = (Element) book.getElementsByTagName("price").item(0);
            // 获取name标签下的文本值
            System.out.println(title.getTextContent());
            // 获取标签上的属性值
            System.out.println(title.getAttribute("id"));
            // 获取author标签下的文本值
            System.out.println(author.getTextContent());
            // 获取price标签下的文本值
            System.out.println(price.getTextContent());
            System.out.println("-------------------");

        }
    }
	 
	 @Test
     public void read() throws Exception{
         //获取工厂
         XMLInputFactory factory = XMLInputFactory.newFactory();
         //获取解析器
         XMLEventReader reader = factory.createXMLEventReader(new FileInputStream("src/books.xml"));
         //使用循环开始读取数据
         while( reader.hasNext() ){
             XMLEvent event = reader.nextEvent();
             if(event.isStartElement()){// <
                 //获取当前这个标签
                 StartElement element = event.asStartElement();
                 //获取标签上的 id属性
                 Attribute attr = element.getAttributeByName(new QName("id"));
                 if( attr != null ){
                     System.out.println("id="+attr.getValue());
                 }
                 //判断当前的标签名是否是name或者author、price
                 if( element.getName().getLocalPart().equals("title") ){
                     XMLEvent text = reader.nextEvent();
                     System.out.println(text.asCharacters());
                 }else if( element.getName().getLocalPart().equals("author") ){
                     XMLEvent text = reader.nextEvent();
                     System.out.println(text.asCharacters());
                 }else if( element.getName().getLocalPart().equals("price") ){
                     XMLEvent text = reader.nextEvent();
                     System.out.println(text.asCharacters());
                 }
                 
             }
             
         }
     }
}
