package com.gec.xml;

import java.io.InputStream;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.junit.Test;

public class TestReadNote2 {
	
	@Test
	public void read() {
		/*
		 * 1 在项目中加入dom4j.jar,加入类路径 
		 * 2 读取src下的note.xml ,用inputStream
		 * 3 创建SaxReader对象 ，解析对象
		 * 4 调用read()返回一个文档Document
		 * 5 获得根元素 ，调用方法getRootElement
		 * 6 获取子元素 to元素
		 *    7 getText返回文本节点，打印内容
		 */
		try(InputStream is = TestReadNote2.class.getResourceAsStream("/note.xml")){
			// 创建SaxReader对象 ，解析对象
			SAXReader reader = new SAXReader();
			// 调用read()返回一个文档Document
			Document doc = reader.read(is);
			//获得根元素 ，调用方法getRootElement
			Element rootElement = doc.getRootElement();
			// 获取子元素 to元素 <to>林志玲</to>
			Element to = rootElement.element("to");
			//getText返回文本节点，打印内容
			String toContent = to.getText();
			System.out.println(to.getName() + ":" + toContent);
			
			//from
			Element from = rootElement.element("from");
			System.out.println(from.getName() + ":" + from.getText());
			
			//title
			String title = rootElement.element("title").getText();
			System.out.println(title);
			
			//简化
			System.out.println(rootElement.elementText("heading"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
